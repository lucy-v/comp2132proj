const words = [
    ["nectarine",
    "Fuzzless fuzzy fruit"
    ],
    ["xylophone",
     "Percussion instrument played with mallets"
    ],
    ["piano",
    "Instrument whose name means 'soft'"
    ],
    ["glove",
    "Appendage covering"
    ],
    ["absolutely",
    "Without a doubt"
    ],
    ["newspaper",
    "Read all over"
    ],
    ["carousel",
    "Goes round and round"
    ],
    ["quarry",
     "Stone mine"
    ],
    ["quicksand",
     "You sink in it"
    ],
    ["mummy",
    "Wrapped in bandages"
    ]
    
];