const popUp = document.getElementById("pop-up");
const answer = document.getElementById("answer");
const playAgain = document.getElementById("play-again");
const game = document.getElementById("game");
const imageMain = document.getElementById("image-main");
const lettersArea = document.getElementById("letters-area");
const guess = document.getElementById("guess");
const hintDisplay = document.getElementById("hint");
const keyboard = document.getElementById("keyboard");
const results = document.getElementById("results");


let currentWord;
let correctLettersSoFar;
let wrongGuessesCounter;
let popUpAnimation;
let won;
let popUpOpacity = 0;
let fadeInDelay = 100;
const maxWrongGuesses = 6;

function resetGame(){
    correctLettersSoFar = [];
    wrongGuessesCounter = 0;
    won = false;
    imageMain.src = "../images/hangman-0.png";
    popUp.style.opacity = 0;
    getNextWord();
    splitWord = currentWord.split("");
    splitWord.forEach(letter => {
        guess.innerHTML += `<li class="letter"></li>`;
    });
    keyboard.querySelectorAll("button").forEach(btn => {btn.disabled = false});
};


//create keyboard buttons
for (let i=97; i<=122; i++){
    const button = document.createElement("button");
    buttonLetter = String.fromCharCode(i);
    console.log("created button: "+buttonLetter)
    button.innerText = buttonLetter;
    keyboard.appendChild(button);
    button.disabled = false;
    button.addEventListener("click", function(){
        console.log("clicked: "+buttonLetter);
        guessLetter(buttonLetter);
        button.disabled = true;
    });
}

function guessLetter(guessedLetter){
    console.log("guessed: "+guessedLetter);

    if (currentWord.includes(guessedLetter)){
        console.log("yes "+guessedLetter);
        correctLettersSoFar.push(guessedLetter);
        if (correctLettersSoFar.length == currentWord.length){
            won = true;
            gameOver();
        }
    } else {
        wrongGuessesCounter++;
        imageMain.src = `../images/hangman-${wrongGuessesCounter}.png`;
        if (wrongGuessesCounter == maxWrongGuesses){
            gameOver();
        }
    };
}

function gameOver(){
    keyboard.querySelectorAll("button").forEach(btn => {btn.disabled = true});
    
    setTimeout(function(){
        popUpAnimation = requestAnimationFrame(fadeIn);
       
   }, fadeInDelay);

    answer.innerHTML = currentWord;
    if(!won){
        results.innerHTML = "You Lost";
    }else{
        results.innerHTML = "You Won";

    }
}

playAgain.addEventListener("click", function(){resetGame()});


const fetchFileURL = 'words.json';


function fetchNextWord(){
    console.log("Fetching next word...");
    //fetch a file
    fetch(fetchFileURL)        
        .then(function(){
            console.log("Deal with fetch response");
        })
        //.catch if fetch failed 
        //possibly due to not running over http
        .catch(function(){            
            console.log("Catch fetch error");
        });

}

function getNextWord(){
    // Returns a random integer from 0 to (length of word list - 1):
    n = Math.floor(Math.random() * (words.length - 1));
    
    const nextWord = words[n][0];
    const nextHint = words[n][1];
    currentWord = nextWord;
    hintDisplay.innerText = nextHint;
}



function fadeIn(){
    if (popUpOpacity < 1){
        popUpOpacity += 0.1;
        popUp.style.opacity = popUpOpacity;
        timeoutHandler = setTimeout(function(){ requestAnimationFrame(fadeIn)}, fadeInDelay);
    }
}

resetGame();
